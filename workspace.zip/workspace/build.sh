#!/usr/bin/env bash
docker build --force-rm=true -t workspace .
