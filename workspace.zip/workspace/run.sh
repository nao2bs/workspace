#!/usr/bin/env bash
docker rm workspace 2 &>/dev/null
docker run -it \
  --name workspace \
  --mount type=bind,source="$(pwd)/nvim",target=/root/.config/nvim \
  --mount type=bind,source="$(pwd)/projects",target=/root/projects \
  workspace
